package Design_qsns.Design_qsns_java.Design_instagram_feed.strategy;
import Design_qsns.Design_qsns_java.Design_instagram_feed.models.*;
import java.util.ArrayList;

public interface IShowFeedStrategy {
    public void showFeed(ArrayList<Post> posts);
}
